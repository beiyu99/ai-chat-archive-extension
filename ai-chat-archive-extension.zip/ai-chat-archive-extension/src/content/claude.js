// src/content/claude.js

(function () {
  if (globalThis.__aiChatArchiveClaudeLoaded) return;
  globalThis.__aiChatArchiveClaudeLoaded = true;

  const PLATFORM = 'claude';

  function getConversationUuid() {
    const m = location.pathname.match(/\/chat\/([a-f0-9-]+)/i);
    return m ? m[1] : null;
  }

  async function getOrgUuid() {
    const res = await fetch('/api/organizations', { credentials: 'include' });
    if (!res.ok) throw new Error('无法获取组织信息，请确保已登录 Claude');
    const orgs = await res.json();
    if (!orgs.length) throw new Error('未找到组织');
    return orgs[0].uuid;
  }

  async function fetchConversation(orgUuid, convUuid) {
    const urls = [
      `/api/organizations/${orgUuid}/chat_conversations/${convUuid}?tree=True&rendering_mode=messages&render_all_tools=true`,
      `/api/organizations/${orgUuid}/chat_conversations/${convUuid}?tree=True&rendering_mode=raw`
    ];

    let lastStatus = 0;
    for (const url of urls) {
      const res = await fetch(url, { credentials: 'include' });
      lastStatus = res.status;
      if (!res.ok) continue;
      return res.json();
    }

    throw new Error(`Claude API 返回 ${lastStatus || '未知错误'}`);
  }

  async function listAllConversations(orgUuid) {
    const url = `/api/organizations/${orgUuid}/chat_conversations`;
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`Claude 列表 API 返回 ${res.status}`);
    const list = await res.json();
    return list.map(c => ({
      id: c.uuid,
      title: c.name || '未命名对话',
      updatedAt: c.updated_at ? new Date(c.updated_at).getTime() : null,
      createdAt: c.created_at ? new Date(c.created_at).getTime() : null
    }));
  }

  function blockToText(block) {
    if (!block) return '';
    if (typeof block === 'string') return block.trim();
    if (Array.isArray(block)) {
      return block.map(blockToText).filter(Boolean).join('\n').trim();
    }

    if (typeof block.text === 'string' && block.type === 'text') {
      return block.text.trim();
    }

    switch (block.type) {
      case 'tool_use': {
        const input = block.input ? `\n${JSON.stringify(block.input, null, 2)}` : '';
        return `[工具调用: ${block.name || 'unknown'}]${input}`.trim();
      }
      case 'tool_result': {
        const content = blockToText(block.content);
        return ['[工具结果]', content].filter(Boolean).join('\n').trim();
      }
      case 'thinking':
        return block.thinking ? `[思考]\n${block.thinking}` : '[思考]';
      case 'redacted_thinking':
        return '[已隐藏思考内容]';
      case 'document':
        return blockToText(block.content) || '[文档]';
      case 'image':
        return '[图片]';
      default: {
        if (typeof block.text === 'string') return block.text.trim();
        if (typeof block.content === 'string') return block.content.trim();
        if (Array.isArray(block.content)) return blockToText(block.content);
        if (block.content && typeof block.content === 'object') return blockToText(block.content);
        return '';
      }
    }
  }

  function messageToText(message) {
    const pieces = [];

    if (typeof message.text === 'string' && message.text.trim()) {
      pieces.push(message.text.trim());
    }

    const contentText = blockToText(message.content);
    if (contentText) {
      const alreadyIncluded = pieces.some(p => p === contentText);
      if (!alreadyIncluded) pieces.push(contentText);
    }

    if (!pieces.length && Array.isArray(message.attachments) && message.attachments.length) {
      pieces.push(`[附件 ${message.attachments.length} 个]`);
    }

    return pieces.join('\n\n').trim();
  }

  function normalize(raw, sourceId = null) {
    const messages = (raw.chat_messages || []).map(m => {
      const text = messageToText(m);
      return {
        role: m.sender === 'human' ? 'user' : 'assistant',
        content: text,
        timestamp: m.created_at ? new Date(m.created_at).getTime() : null
      };
    }).filter(m => m.content);

    return {
      platform: PLATFORM,
      sourceId,
      title: raw.name || '未命名对话',
      createdAt: raw.created_at ? new Date(raw.created_at).getTime() : Date.now(),
      exportedAt: Date.now(),
      messages
    };
  }

  function isVisible(el) {
    return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  }

  function findComposer() {
    const selectors = [
      'div.ProseMirror[contenteditable="true"]',
      'fieldset div[contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]'
    ];
    for (const selector of selectors) {
      const nodes = document.querySelectorAll(selector);
      for (const el of nodes) {
        if (isVisible(el)) return el;
      }
    }
    return null;
  }

  function readComposerText(el) {
    if (!el) return '';
    if (typeof el.value === 'string') return el.value;
    return (el.innerText || el.textContent || '').trim();
  }

  function writeComposerText(el, text) {
    el.focus();
    if (typeof el.value === 'string') {
      el.value = text;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }

    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);

    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, text);
    } catch {}

    if (!inserted) {
      el.textContent = text;
    }

    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      data: text,
      inputType: 'insertText'
    }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function insertArchiveContext(text) {
    const composer = findComposer();
    if (!composer) {
      throw new Error('未找到 Claude 输入框，请先打开可输入的页面后重试');
    }
    const current = readComposerText(composer);
    const next = current ? `${text}\n\n${current}` : text;
    writeComposerText(composer, next);
    return next.length;
  }

  chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
    (async () => {
      try {
        if (req.type === 'PING') {
          sendResponse({ ok: true, platform: PLATFORM });
        } else if (req.type === 'EXTRACT_CONVERSATION') {
          const convUuid = getConversationUuid();
          if (!convUuid) throw new Error('未检测到对话 UUID，请先打开一个具体对话');
          const orgUuid = await getOrgUuid();
          const raw = await fetchConversation(orgUuid, convUuid);
          sendResponse({ ok: true, data: normalize(raw, convUuid) });
        } else if (req.type === 'LIST_CONVERSATIONS') {
          const orgUuid = await getOrgUuid();
          const list = await listAllConversations(orgUuid);
          sendResponse({ ok: true, platform: PLATFORM, items: list });
        } else if (req.type === 'EXTRACT_CONVERSATION_BY_ID') {
          const orgUuid = await getOrgUuid();
          const raw = await fetchConversation(orgUuid, req.id);
          sendResponse({ ok: true, data: normalize(raw, req.id) });
        } else if (req.type === 'INSERT_ARCHIVE_CONTEXT') {
          sendResponse({ ok: true, insertedChars: insertArchiveContext(req.text || '') });
        }
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  });
})();
