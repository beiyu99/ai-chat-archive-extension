// src/content/gemini.js
// Gemini 没有稳定公开接口，全部走 DOM。
// 当前对话：从主区域抓取 user-query / model-response
// 对话列表：从侧边栏抓取可见的历史项（注意：只能抓到当前加载的部分）

(function () {
  if (globalThis.__aiChatArchiveGeminiLoaded) return;
  globalThis.__aiChatArchiveGeminiLoaded = true;

  const PLATFORM = 'gemini';

  function htmlToText(node) {
    if (!node) return '';
    const clone = node.cloneNode(true);
    clone.querySelectorAll('pre code').forEach(code => {
      const lang = (code.className.match(/language-(\w+)/) || [])[1] || '';
      code.textContent = `\n\`\`\`${lang}\n${code.textContent}\n\`\`\`\n`;
    });
    clone.querySelectorAll('code').forEach(code => {
      if (code.parentElement.tagName !== 'PRE') {
        code.textContent = `\`${code.textContent}\``;
      }
    });
    clone.querySelectorAll('strong, b').forEach(el => el.textContent = `**${el.textContent}**`);
    clone.querySelectorAll('em, i').forEach(el => el.textContent = `*${el.textContent}*`);
    clone.querySelectorAll('li').forEach(el => el.textContent = `- ${el.textContent}\n`);
    return clone.innerText.trim();
  }

  function extractMessages() {
    const messages = [];
    const userNodes = document.querySelectorAll('user-query .query-text, user-query .query-content');
    const modelNodes = document.querySelectorAll('model-response .markdown, model-response message-content');
    const len = Math.max(userNodes.length, modelNodes.length);
    for (let i = 0; i < len; i++) {
      if (userNodes[i]) {
        const t = htmlToText(userNodes[i]);
        if (t) messages.push({ role: 'user', content: t, timestamp: null });
      }
      if (modelNodes[i]) {
        const t = htmlToText(modelNodes[i]);
        if (t) messages.push({ role: 'assistant', content: t, timestamp: null });
      }
    }
    return messages;
  }

  function getTitle() {
    const selected = document.querySelector('.conversation.selected, [aria-current="page"] .conversation-title');
    if (selected) return selected.textContent.trim();
    return document.title.replace(/[-—]?\s*Gemini\s*$/i, '').trim() || '未命名对话';
  }

  function getCurrentId() {
    // Gemini URL 形如 /app/xxxxxx
    const m = location.pathname.match(/\/app\/([^/?#]+)/i);
    return m ? decodeURIComponent(m[1]) : location.pathname;
  }

  // 列表：尝试从侧边栏抓历史标题
  function listConversationsFromSidebar() {
    const items = [];
    const nodes = document.querySelectorAll(
      '.conversation, [data-test-id="conversation"], conversations-list .conversation-title'
    );
    nodes.forEach(n => {
      const title = (n.textContent || '').trim();
      const link = n.closest('a') || n.querySelector('a');
      const href = link?.getAttribute('href') || '';
      const idMatch = href.match(/\/app\/([^/?#]+)/i);
      const url = href ? new URL(href, location.origin).toString() : null;
      if (title) {
        items.push({
          id: idMatch ? decodeURIComponent(idMatch[1]) : title, // 退化为标题
          url,
          title,
          updatedAt: null,
          createdAt: null
        });
      }
    });
    return items;
  }

  function isVisible(el) {
    return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  }

  function findComposer() {
    const selectors = [
      'rich-textarea .ql-editor[contenteditable="true"]',
      '.ql-editor[contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]'
    ];
    for (const selector of selectors) {
      const nodes = document.querySelectorAll(selector);
      for (const el of nodes) {
        if (isVisible(el)) return el;
      }
    }
    return null;
  }

  function readComposerText(el) {
    if (!el) return '';
    if (typeof el.value === 'string') return el.value;
    return (el.innerText || el.textContent || '').trim();
  }

  function writeComposerText(el, text) {
    el.focus();
    if (typeof el.value === 'string') {
      el.value = text;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }

    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);

    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, text);
    } catch {}

    if (!inserted) {
      el.textContent = text;
    }

    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      data: text,
      inputType: 'insertText'
    }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function insertArchiveContext(text) {
    const composer = findComposer();
    if (!composer) {
      throw new Error('未找到 Gemini 输入框，请先打开可输入的页面后重试');
    }
    const current = readComposerText(composer);
    const next = current ? `${text}\n\n${current}` : text;
    writeComposerText(composer, next);
    return next.length;
  }

  chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
    try {
      if (req.type === 'PING') {
        sendResponse({ ok: true, platform: PLATFORM });
      } else if (req.type === 'EXTRACT_CONVERSATION') {
        const messages = extractMessages();
        if (!messages.length) {
          sendResponse({ ok: false, error: '未抓到任何消息，Gemini 可能改版了选择器' });
          return true;
        }
        sendResponse({
          ok: true,
          data: {
            platform: PLATFORM,
            sourceId: getCurrentId(),
            title: getTitle(),
            createdAt: Date.now(),
            exportedAt: Date.now(),
            messages
          }
        });
      } else if (req.type === 'LIST_CONVERSATIONS') {
        const items = listConversationsFromSidebar();
        sendResponse({
          ok: true,
          platform: PLATFORM,
          items,
          warning: items.length
            ? 'Gemini 只能抓取侧边栏已加载的对话；批量模式会自动逐个跳转并抓取消息'
            : '未检测到侧边栏对话列表'
        });
      } else if (req.type === 'EXTRACT_CONVERSATION_BY_ID') {
        // Gemini 不支持按 ID 远程拉，必须先跳转打开
        sendResponse({
          ok: false,
          error: 'Gemini 不支持静默按 ID 抓取，请在目标对话打开后再导出'
        });
      } else if (req.type === 'INSERT_ARCHIVE_CONTEXT') {
        sendResponse({ ok: true, insertedChars: insertArchiveContext(req.text || '') });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err.message });
    }
    return true;
  });
})();
