// src/content/chatgpt.js
// 支持的消息类型：
//   EXTRACT_CONVERSATION           抓当前对话
//   LIST_CONVERSATIONS             拉取所有对话索引（分页翻完）
//   EXTRACT_CONVERSATION_BY_ID     抓指定 id 的对话

(function () {
  if (globalThis.__aiChatArchiveChatgptLoaded) return;
  globalThis.__aiChatArchiveChatgptLoaded = true;

  const PLATFORM = 'chatgpt';

  function getConversationId() {
    const m = location.pathname.match(/\/c\/([a-f0-9-]+)/i);
    return m ? m[1] : null;
  }

  async function getAccessToken() {
    const res = await fetch('/api/auth/session', { credentials: 'include' });
    if (!res.ok) throw new Error('无法获取 session，请确保已登录 ChatGPT');
    const data = await res.json();
    return data.accessToken;
  }

  async function apiGet(path) {
    const token = await getAccessToken();
    const res = await fetch(path, {
      headers: { Authorization: `Bearer ${token}` },
      credentials: 'include'
    });
    if (!res.ok) throw new Error(`ChatGPT API ${path} 返回 ${res.status}`);
    return res.json();
  }

  async function fetchConversation(id) {
    return apiGet(`/backend-api/conversation/${id}`);
  }

  async function listAllConversations() {
    const all = [];
    let offset = 0;
    const limit = 100;
    while (true) {
      const data = await apiGet(`/backend-api/conversations?offset=${offset}&limit=${limit}&order=updated`);
      const items = data.items || [];
      for (const it of items) {
        all.push({
          id: it.id,
          title: it.title || '未命名对话',
          updatedAt: it.update_time ? new Date(it.update_time).getTime() : null,
          createdAt: it.create_time ? new Date(it.create_time).getTime() : null
        });
      }
      if (items.length < limit) break;
      offset += limit;
      if (offset >= (data.total || 0)) break;
      if (offset > 5000) break;
    }
    return all;
  }

  function normalize(raw, sourceId = null) {
    const { mapping, title, create_time } = raw;
    const messages = [];
    const root = Object.values(mapping).find(n => !n.parent);
    let node = root;
    while (node) {
      const msg = node.message;
      if (msg && msg.content && msg.author.role !== 'system') {
        const parts = msg.content.parts || [];
        const text = parts
          .map(p => (typeof p === 'string' ? p : JSON.stringify(p)))
          .join('\n')
          .trim();
        if (text) {
          messages.push({
            role: msg.author.role,
            content: text,
            timestamp: msg.create_time ? msg.create_time * 1000 : null
          });
        }
      }
      node = node.children && node.children.length
        ? mapping[node.children[node.children.length - 1]]
        : null;
    }
    return {
      platform: PLATFORM,
      sourceId,
      title: title || '未命名对话',
      createdAt: create_time ? create_time * 1000 : Date.now(),
      exportedAt: Date.now(),
      messages
    };
  }

  function isVisible(el) {
    return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  }

  function findComposer() {
    const selectors = [
      '#prompt-textarea',
      'div#prompt-textarea[contenteditable="true"]',
      'textarea[data-id="root"]'
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (isVisible(el)) return el;
    }
    return null;
  }

  function readComposerText(el) {
    if (!el) return '';
    if (typeof el.value === 'string') return el.value;
    return (el.innerText || el.textContent || '').trim();
  }

  function writeComposerText(el, text) {
    el.focus();
    if (typeof el.value === 'string') {
      el.value = text;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }

    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);

    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, text);
    } catch {}

    if (!inserted) {
      el.textContent = text;
    }

    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      data: text,
      inputType: 'insertText'
    }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function insertArchiveContext(text) {
    const composer = findComposer();
    if (!composer) {
      throw new Error('未找到 ChatGPT 输入框，请先打开可输入的页面后重试');
    }
    const current = readComposerText(composer);
    const next = current ? `${text}\n\n${current}` : text;
    writeComposerText(composer, next);
    return next.length;
  }

  chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
    (async () => {
      try {
        if (req.type === 'PING') {
          sendResponse({ ok: true, platform: PLATFORM });
        } else if (req.type === 'EXTRACT_CONVERSATION') {
          const id = getConversationId();
          if (!id) throw new Error('未检测到对话 ID，请先打开一个具体对话');
          const raw = await fetchConversation(id);
          sendResponse({ ok: true, data: normalize(raw, id) });
        } else if (req.type === 'LIST_CONVERSATIONS') {
          const list = await listAllConversations();
          sendResponse({ ok: true, platform: PLATFORM, items: list });
        } else if (req.type === 'EXTRACT_CONVERSATION_BY_ID') {
          const raw = await fetchConversation(req.id);
          sendResponse({ ok: true, data: normalize(raw, req.id) });
        } else if (req.type === 'INSERT_ARCHIVE_CONTEXT') {
          sendResponse({ ok: true, insertedChars: insertArchiveContext(req.text || '') });
        }
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    })();
    return true;
  });
})();
