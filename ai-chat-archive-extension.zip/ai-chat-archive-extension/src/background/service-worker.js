// src/background/service-worker.js
// 本地消息路由中心：导出、批量、存档搜索、标签管理、本地备份导入导出。

import { toMarkdown } from '../lib/exporters/markdown.js';
import { toHtml } from '../lib/exporters/html.js';
import { toPdfViaPrint } from '../lib/exporters/pdf.js';
import { toJson } from '../lib/exporters/json.js';

const CONTENT_SCRIPT_BY_PLATFORM = {
  chatgpt: 'src/content/chatgpt.js',
  claude: 'src/content/claude.js',
  gemini: 'src/content/gemini.js'
};

// ------------ 通用工具 ------------
function safeFileName(title) {
  const clean = String(title || 'archive').replace(/[\\/:*?"<>|]/g, '_').slice(0, 80);
  const stamp = new Date().toISOString().slice(0, 10);
  return `${stamp}_${clean}`;
}

function normalizeTags(tags = []) {
  return Array.from(new Set((tags || []).map((tag) => String(tag).trim()).filter(Boolean)));
}

function normalizeFormats(formats = []) {
  return Array.from(new Set((formats || []).map((format) => String(format).trim()).filter(Boolean)));
}

function normalizeTimestamp(value, fallback = null) {
  if (value === null || value === undefined || value === '') return fallback;
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function normalizeMessage(msg = {}) {
  const content = typeof msg.content === 'string'
    ? msg.content
    : Array.isArray(msg.content)
      ? msg.content.join('\n')
      : String(msg.content || '').trim();

  return {
    role: String(msg.role || 'assistant'),
    content,
    timestamp: normalizeTimestamp(msg.timestamp, null)
  };
}

function normalizeConversation(conv = {}, options = {}) {
  const now = Date.now();
  const messages = Array.isArray(conv.messages)
    ? conv.messages.map(normalizeMessage).filter((msg) => msg.content)
    : [];

  return {
    platform: String(conv.platform || options.platform || 'unknown'),
    sourceId: conv.sourceId || options.sourceId || null,
    title: String(conv.title || options.title || '未命名对话'),
    createdAt: normalizeTimestamp(conv.createdAt, normalizeTimestamp(options.createdAt, now)),
    exportedAt: normalizeTimestamp(conv.exportedAt, normalizeTimestamp(options.exportedAt, now)),
    tags: normalizeTags(conv.tags || options.tags || []),
    messages
  };
}

function hashString(input) {
  let hash = 2166136261;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(16);
}

function archiveFingerprint(conv) {
  if (conv.archiveFingerprint) return conv.archiveFingerprint;
  const messages = conv.messages || [];
  const first = messages[0]?.content?.slice(0, 160) || '';
  const last = messages[messages.length - 1]?.content?.slice(0, 160) || '';
  return hashString([
    conv.platform || '',
    conv.sourceId || '',
    conv.createdAt || '',
    conv.title || '',
    messages.length,
    first,
    last
  ].join('|'));
}

function archiveKey(conv, fingerprint = archiveFingerprint(conv)) {
  return `conv_${conv.platform}_${fingerprint}`;
}

function buildBackupPayload(archives) {
  return {
    app: 'AI Chat Archive',
    version: 1,
    exportedAt: Date.now(),
    archives: archives.map((archive) => ({
      archiveFingerprint: archive.archiveFingerprint || archiveFingerprint(archive.raw || archive),
      platform: archive.platform,
      sourceId: archive.sourceId || null,
      title: archive.title,
      createdAt: archive.createdAt,
      exportedAt: archive.exportedAt,
      messageCount: archive.messageCount || archive.raw?.messages?.length || 0,
      formats: normalizeFormats(archive.formats || []),
      tags: normalizeTags(archive.tags || []),
      raw: normalizeConversation(archive.raw || archive, {
        platform: archive.platform,
        sourceId: archive.sourceId,
        title: archive.title,
        createdAt: archive.createdAt,
        exportedAt: archive.exportedAt,
        tags: archive.tags || []
      })
    }))
  };
}

function extractImportItems(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.archives)) return payload.archives;
  if (payload?.raw && Array.isArray(payload.raw.messages)) return [payload];
  if (Array.isArray(payload?.messages)) return [payload];
  return [];
}

function normalizeImportRecord(item) {
  const raw = normalizeConversation(item.raw || item, {
    platform: item.platform,
    sourceId: item.sourceId,
    title: item.title,
    createdAt: item.createdAt,
    exportedAt: item.exportedAt,
    tags: item.tags || item.raw?.tags || []
  });

  return {
    conversation: raw,
    formats: normalizeFormats(item.formats || ['json']),
    options: {
      archiveFingerprint: item.archiveFingerprint || item.fingerprint || null,
      exportedAt: normalizeTimestamp(item.exportedAt, raw.exportedAt),
      tags: normalizeTags(item.tags || raw.tags || [])
    }
  };
}

function download(content, filename, mime, saveAs = false) {
  const url = `data:${mime};charset=utf-8,${encodeURIComponent(content)}`;
  return chrome.downloads.download({
    url,
    filename: `ai-chat-archive/${filename}`,
    saveAs
  });
}

async function writeFormats(conv, formats) {
  const base = safeFileName(`${conv.platform}_${conv.title}`);
  if (formats.includes('markdown')) {
    await download(toMarkdown(conv), `${base}.md`, 'text/markdown');
  }
  if (formats.includes('html')) {
    await download(toHtml(conv), `${base}.html`, 'text/html');
  }
  if (formats.includes('json')) {
    await download(toJson(conv), `${base}.json`, 'application/json');
  }
  if (formats.includes('pdf')) {
    toPdfViaPrint(conv);
  }
}

function makeArchiveRecord(conv, formats, prev = null, options = {}) {
  const raw = normalizeConversation({
    ...(prev?.raw || {}),
    ...conv
  }, {
    sourceId: conv.sourceId || prev?.sourceId || null,
    exportedAt: options.exportedAt ?? conv.exportedAt ?? prev?.exportedAt ?? Date.now(),
    tags: options.tags ?? conv.tags ?? prev?.tags ?? []
  });

  const fingerprint = options.archiveFingerprint || prev?.archiveFingerprint || archiveFingerprint(raw);
  const id = archiveKey(raw, fingerprint);

  return {
    id,
    archiveFingerprint: fingerprint,
    sourceId: raw.sourceId || null,
    platform: raw.platform,
    title: raw.title,
    createdAt: raw.createdAt,
    exportedAt: raw.exportedAt,
    messageCount: raw.messages?.length || 0,
    formats: normalizeFormats([...(prev?.formats || []), ...(formats || [])]),
    tags: raw.tags,
    raw
  };
}

async function saveArchive(conv, formats, options = {}) {
  const normalized = normalizeConversation(conv, options);
  const fingerprint = options.archiveFingerprint || archiveFingerprint(normalized);
  const id = archiveKey(normalized, fingerprint);
  const existing = (await chrome.storage.local.get(id))[id] || null;
  const archive = makeArchiveRecord(normalized, formats, existing, {
    ...options,
    archiveFingerprint: fingerprint
  });
  await chrome.storage.local.set({ [id]: archive });
  return archive;
}

async function listLocalArchiveRecords() {
  const all = await chrome.storage.local.get(null);
  return Object.values(all).filter((value) => value?.id?.startsWith('conv_'));
}

async function exportLocalBackup() {
  const archives = (await listLocalArchiveRecords()).sort((a, b) => (b.exportedAt || 0) - (a.exportedAt || 0));
  const payload = buildBackupPayload(archives);
  const filename = `${safeFileName('local_backup')}.json`;
  await download(JSON.stringify(payload, null, 2), filename, 'application/json', true);
  return {
    total: archives.length,
    filename
  };
}

async function importLocalBackup(payload) {
  const items = extractImportItems(payload);
  if (!items.length) {
    throw new Error('导入文件里没有可识别的存档记录');
  }

  let imported = 0;
  const failed = [];

  for (const item of items) {
    try {
      const normalized = normalizeImportRecord(item);
      await saveArchive(normalized.conversation, normalized.formats, normalized.options);
      imported++;
    } catch (err) {
      failed.push(err.message);
    }
  }

  return {
    total: items.length,
    imported,
    failed
  };
}

// ------------ 批量导出状态 ------------
const batchState = {
  running: false,
  total: 0,
  done: 0,
  success: 0,
  failed: 0,
  errors: [],
  startedAt: 0,
  finishedAt: 0,
  current: ''
};

async function saveBatchState() {
  await chrome.storage.session?.set({ batchState }).catch(() => {});
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForTabComplete(tabId, timeoutMs = 20000) {
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === 'complete') return tab;
    await sleep(250);
  }

  throw new Error('页面加载超时');
}

async function sendTabMessage(tabId, platform, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (err) {
    const file = CONTENT_SCRIPT_BY_PLATFORM[platform];
    if (!file) throw err;
    await chrome.scripting.executeScript({
      target: { tabId },
      files: [file]
    });
    return chrome.tabs.sendMessage(tabId, message);
  }
}

async function extractConversationForBatch(tabId, platform, item) {
  if (platform === 'gemini') {
    const currentTab = await chrome.tabs.get(tabId);
    const currentUrl = currentTab.url ? new URL(currentTab.url) : new URL('https://gemini.google.com/app');
    const targetUrl = item.url
      ? new URL(item.url, currentUrl.origin)
      : item.id && item.id !== item.title
        ? new URL(`/app/${encodeURIComponent(item.id)}`, currentUrl.origin)
        : null;

    if (!targetUrl) {
      throw new Error('Gemini 列表项缺少可跳转的对话地址，请先在侧边栏完整展开历史记录后再试');
    }

    const currentLang = currentUrl.searchParams.get('hl');
    if (currentLang && !targetUrl.searchParams.get('hl')) {
      targetUrl.searchParams.set('hl', currentLang);
    }

    await chrome.tabs.update(tabId, { url: targetUrl.toString() });
    await waitForTabComplete(tabId);

    let lastError = 'Gemini 页面已打开，但未抓到消息';
    for (let attempt = 0; attempt < 12; attempt++) {
      await sleep(attempt === 0 ? 1200 : 700);
      try {
        const res = await sendTabMessage(tabId, platform, { type: 'EXTRACT_CONVERSATION' });
        if (res?.ok && res.data?.messages?.length) {
          return res;
        }
        if (res?.error) lastError = res.error;
      } catch (err) {
        lastError = err.message;
      }
    }

    throw new Error(lastError);
  }

  return sendTabMessage(tabId, platform, {
    type: 'EXTRACT_CONVERSATION_BY_ID',
    id: item.id
  });
}

async function runBatchExport({ tabId, platform, ids, formats }) {
  Object.assign(batchState, {
    running: true,
    total: ids.length,
    done: 0,
    success: 0,
    failed: 0,
    errors: [],
    startedAt: Date.now(),
    finishedAt: 0,
    current: ''
  });
  await saveBatchState();

  for (const item of ids) {
    batchState.current = item.title || item.id;
    await saveBatchState();
    try {
      const res = await extractConversationForBatch(tabId, platform, item);
      if (!res?.ok) throw new Error(res?.error || '抓取失败');
      await writeFormats(res.data, formats.filter((format) => format !== 'pdf'));
      await saveArchive(res.data, formats);
      batchState.success++;
    } catch (err) {
      batchState.failed++;
      batchState.errors.push({ id: item.id, title: item.title, error: err.message });
    }
    batchState.done++;
    await saveBatchState();
    await sleep(platform === 'gemini' ? 900 : 400);
  }

  batchState.running = false;
  batchState.finishedAt = Date.now();
  batchState.current = '';
  await saveBatchState();
}

// ------------ 搜索 ------------
async function searchArchives(query) {
  const q = (query || '').trim().toLowerCase();
  if (!q) return [];
  const all = await listLocalArchiveRecords();
  const results = [];

  for (const archive of all) {
    const titleHit = archive.title.toLowerCase().includes(q);
    const tagHit = (archive.tags || []).some((tag) => tag.toLowerCase().includes(q));
    let snippetHit = '';

    if (!titleHit && !tagHit && archive.raw?.messages) {
      for (const message of archive.raw.messages) {
        const text = String(message.content || '');
        const idx = text.toLowerCase().indexOf(q);
        if (idx >= 0) {
          const start = Math.max(0, idx - 40);
          const end = Math.min(text.length, idx + q.length + 40);
          snippetHit = (start > 0 ? '…' : '') + text.slice(start, end) + (end < text.length ? '…' : '');
          break;
        }
      }
    }

    if (titleHit || tagHit || snippetHit) {
      results.push({
        id: archive.id,
        platform: archive.platform,
        title: archive.title,
        messageCount: archive.messageCount,
        exportedAt: archive.exportedAt,
        tags: archive.tags || [],
        snippet: snippetHit,
        matchedIn: titleHit ? 'title' : tagHit ? 'tag' : 'content'
      });
    }
  }

  results.sort((a, b) => (b.exportedAt || 0) - (a.exportedAt || 0));
  return results;
}

async function allTags() {
  const all = await listLocalArchiveRecords();
  const counts = {};
  for (const archive of all) {
    for (const tag of archive.tags || []) {
      counts[tag] = (counts[tag] || 0) + 1;
    }
  }
  return Object.entries(counts)
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count);
}

// ------------ 消息路由 ------------
chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
  (async () => {
    try {
      switch (req.type) {
        case 'EXPORT_CONVERSATION': {
          const { conversation, formats, tags } = req;
          if (tags) conversation.tags = tags;
          await writeFormats(conversation, formats);
          const archive = await saveArchive(conversation, formats);
          sendResponse({ ok: true, archiveId: archive.id });
          break;
        }
        case 'BATCH_EXPORT_START': {
          if (batchState.running) {
            sendResponse({ ok: false, error: '已有批量任务在执行，请等待完成' });
            return;
          }
          runBatchExport(req).catch(() => {});
          sendResponse({ ok: true });
          break;
        }
        case 'BATCH_PROGRESS_QUERY': {
          sendResponse({ ok: true, state: { ...batchState } });
          break;
        }
        case 'LIST_ARCHIVES': {
          const archives = (await listLocalArchiveRecords())
            .map((archive) => ({
              id: archive.id,
              platform: archive.platform,
              title: archive.title,
              messageCount: archive.messageCount,
              createdAt: archive.createdAt,
              exportedAt: archive.exportedAt,
              tags: archive.tags || []
            }))
            .sort((a, b) => (b.exportedAt || 0) - (a.exportedAt || 0));
          sendResponse({ ok: true, archives });
          break;
        }
        case 'SEARCH_ARCHIVES': {
          const results = await searchArchives(req.query);
          sendResponse({ ok: true, results });
          break;
        }
        case 'GET_ARCHIVE': {
          const result = await chrome.storage.local.get(req.id);
          sendResponse({ ok: true, archive: result[req.id] });
          break;
        }
        case 'DELETE_ARCHIVE': {
          await chrome.storage.local.remove(req.id);
          sendResponse({ ok: true });
          break;
        }
        case 'UPDATE_TAGS': {
          const result = await chrome.storage.local.get(req.id);
          const archive = result[req.id];
          if (!archive) throw new Error('存档不存在');
          const saved = await saveArchive(
            { ...archive.raw, tags: req.tags || [] },
            archive.formats || [],
            {
              archiveFingerprint: archive.archiveFingerprint,
              tags: req.tags || [],
              exportedAt: archive.exportedAt
            }
          );
          sendResponse({ ok: true, tags: saved.tags });
          break;
        }
        case 'GET_ALL_TAGS': {
          sendResponse({ ok: true, tags: await allTags() });
          break;
        }
        case 'EXPORT_LOCAL_BACKUP': {
          const result = await exportLocalBackup();
          sendResponse({ ok: true, ...result });
          break;
        }
        case 'IMPORT_LOCAL_BACKUP': {
          const result = await importLocalBackup(req.payload);
          sendResponse({ ok: true, ...result });
          break;
        }
        default:
          return;
      }
    } catch (err) {
      sendResponse({ ok: false, error: err.message });
    }
  })();
  return true;
});
