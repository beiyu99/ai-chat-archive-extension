# AI Chat Archive

Chrome / Edge 扩展：把 ChatGPT、Claude、Gemini 上的对话导出为 Markdown / HTML / JSON / PDF，支持批量导出、本地全文搜索、标签管理、离线浏览，以及本地备份导入导出。

## 安装

1. 打开 `chrome://extensions`（Edge：`edge://extensions`）
2. 右上角开启**开发者模式**
3. 点**加载已解压的扩展程序**，选中本项目目录（`ai-chat-archive-extension/`）
4. 在 ChatGPT / Claude / Gemini 页面打开对话后，点扩展图标即可

## 功能

### 1. 单条导出（"导出" tab）
在当前打开的对话页面直接点击导出，支持：
- **Markdown**（.md）
- **HTML**（内联样式，双击可在浏览器打开）
- **JSON**（原始结构，便于二次处理）
- **PDF**（走浏览器原生打印对话框，保真度最高）
- 可附加**标签**，方便后续筛选

### 2. 批量导出（"批量" tab）
- 一键拉取平台上**所有对话**的列表
- 勾选需要的，选好格式后批量导出
- 实时进度条 + 失败统计
- 自动限流（每条 400ms），避免触发平台速率限制

> ChatGPT、Claude 走的是内部 API，可以完整批量抓取。  
> Gemini 因为没有公开接口，只能抓侧边栏已加载的对话标题，且批量抓取消息需要逐个打开对话。

### 3. 本地搜索 + 标签管理（"已存档" tab）
- 搜索框实时匹配**标题、标签、消息内容**（带内容片段高亮）
- 标签筛选：所有存过的标签会列在顶部，点击即筛选
- 每条存档可**编辑标签**、**离线浏览**、**删除**

### 4. 离线浏览
点存档的"浏览"按钮，在新标签里用保存的原始数据重新渲染成聊天界面，样式跟 HTML 导出一致。完全离线，断网也能看。

### 5. 本地备份 + 本地导入
- 在"已存档"页签里可一键**导出本地备份**
- 会把当前浏览器里的全部存档打包成一个 JSON 文件
- 后续在新浏览器、重装扩展后，可通过**导入本地备份**重新恢复查看
- 导入后可继续搜索、打标签、离线浏览，并可再次"发给当前 AI"

## 项目结构

```
chat-archive/
├── manifest.json
├── icons/                      # 16/48/128 PNG（已生成好）
├── src/
│   ├── background/
│   │   └── service-worker.js   # 核心：路由消息、批量调度、搜索、标签、本地备份
│   ├── content/
│   │   ├── chatgpt.js          # 内部 API：/backend-api/conversation
│   │   ├── claude.js           # 内部 API：/api/organizations/*/chat_conversations
│   │   └── gemini.js           # DOM 抓取
│   ├── popup/
│   │   ├── popup.html
│   │   ├── popup.css
│   │   └── popup.js            # 三 tab UI
│   ├── viewer/
│   │   ├── viewer.html
│   │   └── viewer.js           # 离线浏览
│   └── lib/exporters/
│       ├── markdown.js
│       ├── html.js
│       ├── json.js
│       └── pdf.js
```

## 各平台抓取机制

| 平台 | 单条抓取 | 列表/批量 | 稳定性 |
|------|----------|-----------|--------|
| ChatGPT | `/backend-api/conversation/{id}` | `/backend-api/conversations?offset=X&limit=100` | ⭐⭐⭐⭐⭐ |
| Claude | `/api/organizations/{org}/chat_conversations/{uuid}` | `/api/organizations/{org}/chat_conversations` | ⭐⭐⭐⭐⭐ |
| Gemini | DOM 选择器 `user-query` / `model-response` | 侧边栏 DOM | ⭐⭐（改版可能失效） |

Gemini 选择器集中在 `src/content/gemini.js`，改版时只需更新那几个 CSS selector。

## 存储位置

- **导出的文件**：浏览器默认下载目录下的 `ai-chat-archive/` 子目录
- **索引 + 原始对话**：Chrome 自己的 `chrome.storage.local`（每扩展配额 10MB，够几千条对话用；不够了可以导出 JSON 再清）
## 已知限制

- Gemini 批量导出因为没有 API，需要用户手动逐个打开对话（已在提示中说明）
- `chrome.storage.local` 有 10MB 上限；如果存档特别大，可以考虑只保留索引，删除 `raw` 字段
- PDF 走打印对话框，批量模式下会跳过 PDF，因为连续弹出多个打印窗口体验不好

## 可能的扩展方向

- 迁移到 IndexedDB（用 Dexie）以突破 10MB 限制
- 支持把多个备份文件合并导入
- 按日期 / 平台分组显示存档
- 单条对话增量同步（只拉取新增消息）
