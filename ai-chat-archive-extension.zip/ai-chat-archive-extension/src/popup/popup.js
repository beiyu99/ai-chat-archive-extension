// src/popup/popup.js
// UI 状态用简单的模块变量维护即可，不上框架。

const PLATFORMS = {
  'chatgpt.com': { id: 'chatgpt', name: 'ChatGPT' },
  'chat.openai.com': { id: 'chatgpt', name: 'ChatGPT' },
  'claude.ai': { id: 'claude', name: 'Claude' },
  'gemini.google.com': { id: 'gemini', name: 'Gemini' }
};
const PLATFORM_NAME = { chatgpt: 'ChatGPT', claude: 'Claude', gemini: 'Gemini' };
const CONTENT_SCRIPT_BY_PLATFORM = {
  chatgpt: 'src/content/chatgpt.js',
  claude: 'src/content/claude.js',
  gemini: 'src/content/gemini.js'
};

let batchList = [];
let selectedIds = new Set();
let activeTagFilter = null;
const ARCHIVE_CONTEXT_LIMIT = 18000;

// ------------ 工具 ------------
function detectPlatform(url) {
  if (!url) return null;
  try {
    return PLATFORMS[new URL(url).hostname] || null;
  } catch {
    return null;
  }
}

async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function ensureContentScript(tab, platform) {
  if (!tab?.id || !platform?.id) {
    throw new Error('请在 ChatGPT / Claude / Gemini 页面使用');
  }

  try {
    const ping = await chrome.tabs.sendMessage(tab.id, { type: 'PING' });
    if (ping?.ok) return;
  } catch {}

  const scriptFile = CONTENT_SCRIPT_BY_PLATFORM[platform.id];
  if (!scriptFile) {
    throw new Error('当前页面暂不支持');
  }

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: [scriptFile]
  });

  try {
    const ping = await chrome.tabs.sendMessage(tab.id, { type: 'PING' });
    if (ping?.ok) return;
  } catch {}

  throw new Error('当前页面尚未准备好，请刷新页面后再试');
}

async function sendPlatformMessage(tab, message) {
  const platform = detectPlatform(tab?.url);
  await ensureContentScript(tab, platform);
  return chrome.tabs.sendMessage(tab.id, message);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]
  ));
}

function showStatus(targetId, msg, kind = 'success') {
  const el = document.getElementById(targetId);
  if (!el) return;
  el.className = `status ${kind}`;
  el.textContent = msg;
}

function clearStatus(targetId) {
  const el = document.getElementById(targetId);
  if (!el) return;
  el.className = 'status';
  el.textContent = '';
}

function formatTime(ts) {
  return ts ? new Date(ts).toLocaleString('zh-CN') : '未知';
}

function roleLabel(role) {
  if (role === 'user') return 'User';
  if (role === 'assistant') return 'Assistant';
  return role || 'Unknown';
}

function trimContext(text, maxChars = ARCHIVE_CONTEXT_LIMIT) {
  if (text.length <= maxChars) return { text, truncated: false };
  const headLen = Math.floor(maxChars * 0.45);
  const tailLen = Math.floor(maxChars * 0.35);
  const omitted = text.length - headLen - tailLen;
  return {
    truncated: true,
    text: [
      text.slice(0, headLen),
      '',
      `[中间已省略约 ${omitted} 个字符，避免一次性注入过长上下文]`,
      '',
      text.slice(-tailLen)
    ].join('\n')
  };
}

function buildArchiveContextPrompt(archive) {
  const conv = archive?.raw;
  if (!conv?.messages?.length) {
    throw new Error('该存档没有可用消息');
  }

  const header = [
    '以下是我之前保存的一段历史对话存档，请把它作为后续回答的背景资料使用。',
    '如果我接下来给出新的要求，以我新的要求为准；不需要复述整段历史，除非我明确要求。',
    '',
    `[存档标题] ${conv.title || archive.title || '未命名对话'}`,
    `[来源平台] ${PLATFORM_NAME[conv.platform] || conv.platform || archive.platform || '未知'}`,
    `[创建时间] ${formatTime(conv.createdAt || archive.createdAt)}`,
    `[导出时间] ${formatTime(conv.exportedAt || archive.exportedAt)}`,
    `[消息数] ${conv.messages.length}`,
    archive?.tags?.length ? `[标签] ${archive.tags.join(', ')}` : null,
    '',
    '[历史对话开始]'
  ].filter(Boolean);

  const messages = conv.messages.map((msg, index) => {
    const time = msg.timestamp ? ` (${formatTime(msg.timestamp)})` : '';
    return `### ${index + 1}. ${roleLabel(msg.role)}${time}\n${msg.content}`.trim();
  });

  const footer = [
    '[历史对话结束]',
    '',
    '我接下来会基于这份历史记录继续提问。'
  ];

  return trimContext([...header, ...messages, ...footer].join('\n\n'));
}

async function getArchiveDetail(id) {
  const res = await chrome.runtime.sendMessage({ type: 'GET_ARCHIVE', id });
  if (!res?.ok || !res.archive) {
    throw new Error('未找到该存档');
  }
  return res.archive;
}

async function sendArchiveToCurrentAi(id) {
  clearStatus('archive-status');
  showStatus('archive-status', '正在写入当前 AI 输入框…', 'info');

  try {
    const archive = await getArchiveDetail(id);
    const { text, truncated } = buildArchiveContextPrompt(archive);
    const tab = await getCurrentTab();
    const platform = detectPlatform(tab?.url);
    const res = await sendPlatformMessage(tab, {
      type: 'INSERT_ARCHIVE_CONTEXT',
      text
    });

    if (!res?.ok) throw new Error(res?.error || '写入失败');

    const tip = truncated ? '，内容过长已自动截断' : '';
    showStatus(
      'archive-status',
      `已写入 ${platform?.name || '当前 AI'} 输入框${tip}，现在可以继续提问了`,
      'success'
    );
  } catch (err) {
    showStatus('archive-status', err.message, 'error');
  }
}

// ------------ Tab 切换 ------------
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((item) => item.classList.remove('active'));
    document.querySelectorAll('.panel').forEach((panel) => panel.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(`panel-${tab.dataset.tab}`).classList.add('active');

    if (tab.dataset.tab === 'archives') {
      loadArchives();
      loadTagFilters();
    } else if (tab.dataset.tab === 'batch') {
      initBatchPanel();
    }
  });
});

// ========================================================
// 单条导出 Tab
// ========================================================
async function initExportPanel() {
  const tab = await getCurrentTab();
  const platform = detectPlatform(tab?.url);
  const badge = document.getElementById('platform-badge');
  const btn = document.getElementById('export-btn');

  if (platform) {
    badge.textContent = `当前页面：${platform.name}`;
    badge.classList.remove('unknown');
    btn.disabled = false;
  } else {
    badge.textContent = '请在 ChatGPT / Claude / Gemini 打开对话再使用';
    badge.classList.add('unknown');
    btn.disabled = true;
  }
}

document.getElementById('export-btn').addEventListener('click', async () => {
  const btn = document.getElementById('export-btn');
  btn.disabled = true;
  btn.textContent = '导出中…';

  try {
    const formats = Array.from(document.querySelectorAll('input[name="format"]:checked'))
      .map((input) => input.value);
    if (!formats.length) throw new Error('请至少选择一种导出格式');

    const tagsRaw = document.getElementById('export-tags').value.trim();
    const tags = tagsRaw
      ? tagsRaw.split(/[,，\s]+/).map((tag) => tag.trim()).filter(Boolean)
      : [];

    const tab = await getCurrentTab();
    const res = await sendPlatformMessage(tab, { type: 'EXTRACT_CONVERSATION' });
    if (!res?.ok) throw new Error(res?.error || '抓取失败');

    const saveRes = await chrome.runtime.sendMessage({
      type: 'EXPORT_CONVERSATION',
      conversation: res.data,
      formats,
      tags
    });
    if (!saveRes?.ok) throw new Error(saveRes?.error || '保存失败');

    showStatus('status', `已导出：${res.data.title}（${res.data.messages.length} 条消息）`, 'success');
  } catch (err) {
    showStatus('status', err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '导出当前对话';
  }
});

// ========================================================
// 批量导出 Tab
// ========================================================
async function initBatchPanel() {
  const tab = await getCurrentTab();
  const platform = detectPlatform(tab?.url);
  const badge = document.getElementById('batch-platform-badge');
  if (platform) {
    badge.textContent = `当前页面：${platform.name}`;
    badge.classList.remove('unknown');
    document.getElementById('batch-list-btn').disabled = false;
  } else {
    badge.textContent = '请在 ChatGPT / Claude / Gemini 页面使用';
    badge.classList.add('unknown');
    document.getElementById('batch-list-btn').disabled = true;
  }
  pollBatchProgress();
}

document.getElementById('batch-list-btn').addEventListener('click', async () => {
  const btn = document.getElementById('batch-list-btn');
  btn.disabled = true;
  btn.textContent = '拉取中…';
  try {
    const tab = await getCurrentTab();
    const res = await sendPlatformMessage(tab, { type: 'LIST_CONVERSATIONS' });
    if (!res?.ok) throw new Error(res?.error || '拉取失败');
    batchList = res.items || [];
    selectedIds = new Set();
    renderBatchList();
    if (res.warning) alert(res.warning);
  } catch (err) {
    alert(`拉取失败：${err.message}`);
  } finally {
    btn.disabled = false;
    btn.textContent = '拉取对话列表';
  }
});

function renderBatchList() {
  const list = document.getElementById('batch-list');
  if (!batchList.length) {
    list.innerHTML = '<div class="empty">列表为空</div>';
    updateBatchControls();
    return;
  }

  list.innerHTML = batchList.map((item) => {
    const checked = selectedIds.has(item.id) ? 'checked' : '';
    const date = item.updatedAt ? new Date(item.updatedAt).toLocaleDateString('zh-CN') : '';
    return `
      <label class="batch-list-item">
        <input type="checkbox" data-id="${escapeHtml(item.id)}" ${checked}>
        <span class="title">${escapeHtml(item.title)}</span>
        <span class="date">${date}</span>
      </label>
    `;
  }).join('');

  list.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
    checkbox.addEventListener('change', (event) => {
      const id = event.target.dataset.id;
      if (event.target.checked) selectedIds.add(id);
      else selectedIds.delete(id);
      updateBatchControls();
    });
  });

  updateBatchControls();
}

document.getElementById('batch-select-all').addEventListener('change', (event) => {
  if (event.target.checked) batchList.forEach((item) => selectedIds.add(item.id));
  else selectedIds.clear();
  renderBatchList();
});

function updateBatchControls() {
  document.getElementById('selected-count').textContent = `已选 ${selectedIds.size} 项`;
  document.getElementById('batch-run-btn').disabled = selectedIds.size === 0;
  const all = document.getElementById('batch-select-all');
  all.checked = batchList.length > 0 && selectedIds.size === batchList.length;
}

document.getElementById('batch-run-btn').addEventListener('click', async () => {
  const formats = Array.from(document.querySelectorAll('input[name="bformat"]:checked'))
    .map((input) => input.value);
  if (!formats.length) return alert('请至少勾选一种格式');

  const selected = batchList.filter((item) => selectedIds.has(item.id));
  if (!selected.length) return;

  if (!confirm(`即将批量导出 ${selected.length} 个对话。大量对话可能需要几分钟，期间请保持扩展打开。继续？`)) return;

  const tab = await getCurrentTab();
  const platform = detectPlatform(tab.url);

  const res = await chrome.runtime.sendMessage({
    type: 'BATCH_EXPORT_START',
    tabId: tab.id,
    platform: platform?.id,
    ids: selected,
    formats
  });
  if (!res?.ok) return alert(`启动失败：${res.error}`);

  document.getElementById('batch-progress').style.display = 'block';
  pollBatchProgress();
});

let progressTimer = null;
async function pollBatchProgress() {
  if (progressTimer) clearTimeout(progressTimer);

  try {
    const res = await chrome.runtime.sendMessage({ type: 'BATCH_PROGRESS_QUERY' });
    if (!res?.ok) return;
    const state = res.state;

    const progress = document.getElementById('batch-progress');
    const fill = document.getElementById('progress-fill');
    const text = document.getElementById('progress-text');

    if (!state.running && state.done === 0 && state.total === 0) {
      progress.style.display = 'none';
      return;
    }

    progress.style.display = 'block';
    const pct = state.total ? Math.round((state.done / state.total) * 100) : 0;
    fill.style.width = `${pct}%`;

    if (state.running) {
      text.textContent = `${state.done}/${state.total} · 当前：${state.current || '…'}`;
      progressTimer = setTimeout(pollBatchProgress, 800);
    } else {
      text.textContent = `完成：成功 ${state.success}，失败 ${state.failed}`;
      if (state.errors.length) {
        text.textContent += `（前 3 个错误：${state.errors.slice(0, 3).map((item) => item.title || item.id).join('; ')}）`;
      }
    }
  } catch {}
}

// ========================================================
// 已存档 Tab（搜索 + 标签筛选 + 本地备份）
// ========================================================
let searchTimer = null;
document.getElementById('search-input').addEventListener('input', (event) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => doSearch(event.target.value), 200);
});

async function doSearch(query) {
  if (!query.trim()) {
    loadArchives();
    return;
  }

  const res = await chrome.runtime.sendMessage({ type: 'SEARCH_ARCHIVES', query });
  if (!res?.ok) return;
  renderArchives(res.results, true);
}

async function loadTagFilters() {
  const res = await chrome.runtime.sendMessage({ type: 'GET_ALL_TAGS' });
  const wrap = document.getElementById('tag-filter');
  if (!res?.ok || !res.tags.length) {
    wrap.innerHTML = '';
    return;
  }

  wrap.innerHTML = `<span class="tag-chip ${!activeTagFilter ? 'active' : ''}" data-tag="">全部</span>` +
    res.tags.map((tag) => (
      `<span class="tag-chip ${activeTagFilter === tag.tag ? 'active' : ''}" data-tag="${escapeHtml(tag.tag)}">${escapeHtml(tag.tag)}<span class="count">${tag.count}</span></span>`
    )).join('');

  wrap.querySelectorAll('.tag-chip').forEach((element) => {
    element.addEventListener('click', () => {
      activeTagFilter = element.dataset.tag || null;
      loadTagFilters();
      loadArchives();
    });
  });
}

async function loadArchives() {
  const list = document.getElementById('archive-list');
  list.innerHTML = '<div class="empty">加载中…</div>';
  clearStatus('archive-status');

  const res = await chrome.runtime.sendMessage({ type: 'LIST_ARCHIVES' });
  if (!res?.ok) return;

  let archives = res.archives || [];
  if (activeTagFilter) {
    archives = archives.filter((archive) => (archive.tags || []).includes(activeTagFilter));
  }
  renderArchives(archives, false);
}

function renderArchives(items, isSearch) {
  const list = document.getElementById('archive-list');
  if (!items.length) {
    list.innerHTML = `<div class="empty">${isSearch ? '未匹配到存档' : '还没有存档，先去“导出”吧'}</div>`;
    return;
  }

  list.innerHTML = '';
  for (const archive of items) {
    const item = document.createElement('div');
    item.className = 'archive-item';
    const tagHtml = (archive.tags || []).map((tag) => `<span class="tag-chip">${escapeHtml(tag)}</span>`).join('');
    item.innerHTML = `
      <div class="title">${escapeHtml(archive.title)}</div>
      <div class="meta">${PLATFORM_NAME[archive.platform] || archive.platform} · ${archive.messageCount} 条 · ${formatTime(archive.exportedAt)}</div>
      ${tagHtml ? `<div class="tags">${tagHtml}</div>` : ''}
      ${archive.snippet ? `<div class="snippet">…${escapeHtml(archive.snippet)}…</div>` : ''}
      <div class="actions">
        <button class="mini context send-btn">发给当前 AI</button>
        <button class="mini view-btn">浏览</button>
        <button class="mini tag-btn">标签</button>
        <button class="mini danger delete-btn">删除</button>
      </div>
    `;

    item.querySelector('.send-btn').addEventListener('click', () => sendArchiveToCurrentAi(archive.id));
    item.querySelector('.view-btn').addEventListener('click', () => openViewer(archive.id));
    item.querySelector('.tag-btn').addEventListener('click', () => editTags(archive));
    item.querySelector('.delete-btn').addEventListener('click', async () => {
      if (!confirm('确认删除该存档？')) return;
      await chrome.runtime.sendMessage({ type: 'DELETE_ARCHIVE', id: archive.id });
      loadArchives();
      loadTagFilters();
    });
    list.appendChild(item);
  }
}

async function editTags(archive) {
  const current = (archive.tags || []).join(', ');
  const input = prompt(`编辑标签（逗号分隔）：\n${archive.title}`, current);
  if (input === null) return;

  const tags = input.split(/[,，\s]+/).map((tag) => tag.trim()).filter(Boolean);
  const res = await chrome.runtime.sendMessage({ type: 'UPDATE_TAGS', id: archive.id, tags });
  if (res?.ok) {
    loadArchives();
    loadTagFilters();
  }
}

function openViewer(id) {
  const url = chrome.runtime.getURL(`src/viewer/viewer.html?id=${encodeURIComponent(id)}`);
  chrome.tabs.create({ url });
}

async function exportLocalBackup() {
  clearStatus('archive-status');
  showStatus('archive-status', '正在生成本地备份文件…', 'info');

  try {
    const res = await chrome.runtime.sendMessage({ type: 'EXPORT_LOCAL_BACKUP' });
    if (!res?.ok) throw new Error(res?.error || '导出备份失败');
    showStatus('archive-status', `已生成本地备份，共 ${res.total} 条存档`, 'success');
  } catch (err) {
    showStatus('archive-status', err.message, 'error');
  }
}

async function importLocalBackup(file) {
  clearStatus('archive-status');
  showStatus('archive-status', `正在导入 ${file.name}…`, 'info');

  try {
    const text = await file.text();
    const payload = JSON.parse(text);
    const res = await chrome.runtime.sendMessage({
      type: 'IMPORT_LOCAL_BACKUP',
      payload
    });
    if (!res?.ok) throw new Error(res?.error || '导入失败');

    const failedCount = res.failed?.length || 0;
    const suffix = failedCount ? `，失败 ${failedCount} 条` : '';
    await loadArchives();
    await loadTagFilters();
    showStatus('archive-status', `导入完成：共 ${res.total} 条，成功 ${res.imported} 条${suffix}`, failedCount ? 'info' : 'success');
  } catch (err) {
    showStatus('archive-status', `导入失败：${err.message}`, 'error');
  }
}

document.getElementById('backup-export-btn').addEventListener('click', exportLocalBackup);
document.getElementById('backup-import-btn').addEventListener('click', () => {
  document.getElementById('backup-import-input').click();
});
document.getElementById('backup-import-input').addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file) return;
  await importLocalBackup(file);
});

document.getElementById('promo-link-btn').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://aixiaoxin.club' });
});

// ------------ 启动 ------------
initExportPanel();
