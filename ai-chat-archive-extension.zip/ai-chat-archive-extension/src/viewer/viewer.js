// src/viewer/viewer.js
import { toHtml } from '../lib/exporters/html.js';

(async () => {
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const root = document.getElementById('root');

  if (!id) {
    root.innerHTML = '<div class="error">缺少 id 参数</div>';
    return;
  }

  const res = await chrome.runtime.sendMessage({ type: 'GET_ARCHIVE', id });
  if (!res?.ok || !res.archive) {
    root.innerHTML = '<div class="error">未找到该存档</div>';
    return;
  }

  // 复用 HTML 导出器的渲染，但只取 body 内容避免重复 <html>
  const fullHtml = toHtml(res.archive.raw);
  const match = fullHtml.match(/<body>([\s\S]*)<\/body>/);
  const bodyContent = match ? match[1] : fullHtml;

  // 样式也一并拿出来注入
  const styleMatch = fullHtml.match(/<style>([\s\S]*?)<\/style>/);
  if (styleMatch) {
    const style = document.createElement('style');
    style.textContent = styleMatch[1];
    document.head.appendChild(style);
  }
  root.innerHTML = bodyContent;
  document.title = res.archive.title;
})();
